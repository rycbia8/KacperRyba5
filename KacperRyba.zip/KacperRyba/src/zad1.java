public class zad1{

    public static void main(String[] args) {

        System.out.print("Według mnie najlepsze gry to:");
        System.out.print("\n Minecraft");
        System.out.print("\n CS:GO");
        System.out.print("\n CS 1.6");

        System.out.print("\n\nWedług mnie najgorsze gry to:");
        System.out.print("\n LOL");
        System.out.print("\n Fortnite");
        System.out.print("\n Valorant");

    }

}