public class Zad4{

    public static void main(String[] args) {

        char letter;
        letter= 'A';
        System.out.print(letter);

    }

}