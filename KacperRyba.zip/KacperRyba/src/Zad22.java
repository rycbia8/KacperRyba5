public class Zad22 {
}
