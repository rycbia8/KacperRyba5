public class Zad7{

    public static void main(String[] args) {

        double mazowieckie, Sprzedaz, SprzedazMazowieckie;
        mazowieckie = 0.62;
        Sprzedaz = 4.6;
        SprzedazMazowieckie = mazowieckie * Sprzedaz;




        System.out.print("\nSprzedaż w rejonie mazowieckim w ciągu roku wynosi: " +SprzedazMazowieckie);
        System.out.print(" mln złotych");

    }

}

