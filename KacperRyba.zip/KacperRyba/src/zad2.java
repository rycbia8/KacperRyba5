public class zad2{

    public static void main(String[] args) {
        // 15.02.2022 dzisiejsza data
        System.out.print("Arkadiusz Baran");
        System.out.print("\nKamionka Wielka x");
        System.out.print("\nKamionka Wielka 33-334");
        System.out.print("\n666 666 666");

    }

}

